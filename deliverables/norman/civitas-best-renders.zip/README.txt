CIVITAS / Norman / 6 November 2026

Four curated Blender geometry reviews under renders/.
Simulation evidence and a UI layout study are separate under evidence/.
None are Roblox Studio screenshots. Not final production art.
See RENDER-REVIEW.md for inspected decisions and rejected iterations.
